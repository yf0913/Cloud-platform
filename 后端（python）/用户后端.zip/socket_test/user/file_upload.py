# coding=utf-8
import os
import socket
from sys import argv

HOST = "192.168.3.36"
PORT = 6633
SHOST = "192.168.247.136"
SPORT = 6635
CHOST = "192.168.247.135"
CPORT = 6635

def file_up(path,address):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(address)
    with open(path, 'rb') as f:
        lenth = 0
        while 1:
            data = f.read(1024)
            if lenth:
                s.send(data)
            else:
                s.send(path.encode() + '####'.encode() + data)
            if len(data) < 1024:
                break
            lenth += len(data)
    s.close()
    print "success"

if __name__ == '__main__':
    S_path = argv[1]
    #S_path.replace("\\","/")
    #S_path = "D:/pycharm_dir/socket_test/Test_P_Warehouse/protocol_D/protocol_D_S.py"
    S_address = (SHOST,SPORT)
    C_path = argv[2]
    #C_path = "D:/pycharm_dir/socket_test/Test_P_Warehouse/protocol_D/protocol_D_C.py"
    C_address = (CHOST,CPORT)

    # s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # s.connect((SHOST, SPORT))
    file_up(S_path,S_address)
    print "mid"
    file_up(C_path,C_address)

    #os.remove(path)
