# coding=utf-8
#测试用，与本体无关
import os
import socket
HOST = "192.168.3.36"
PORT = 6633
SPORT = 6634

def controller(name):
    os.system("python D:/pycharm_dir/socket_test/server（测试用）/Warehouse/"+name)

if __name__ == '__main__':
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.bind((HOST,PORT))
    s.listen(5)
    print "start listening!"
    count = 0
    while True:
        connect,addr = s.accept()
        data = connect.recv(1024)
        print "run:"+data
        controller(data)
        connect.close()
        if data =="-1":
            break
    s.close()

