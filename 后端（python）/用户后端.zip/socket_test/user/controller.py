# coding=utf-8
import sys
import socket
HOST = "192.168.3.36"
PORT = 6634
SHOST = "192.168.247.136"
SPORT = 6634
CHOST = "192.168.247.135"
CPORT = 6634

def controll(Sname,Cname):
     s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
     s.connect((SHOST, SPORT))
     s.send(Sname)
     s.close()
     c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
     c.connect((CHOST, CPORT))
     c.send(Cname)
     c.close()
     # 消息接收
     l = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
     l.bind((HOST, PORT))
     l.listen(2)
     for i in [1, 2]:
          conn, adrr = l.accept()
          data = conn.recv(1024)
          data = data + "\n"
          print (data)
     l.close()

if __name__ == '__main__':
     #测试数据：
     #protocol_A_S = "protocol_A_S.py"
     #protocol_A_C = "protocol_A_C.py"
     #protocol_B_S = "protocol_B_S.py"
     #protocol_B_C = "protocol_B_C.py"
     #protocol_name = sys.argv[1]

     protocol_S = sys.argv[1]
     protocol_C = sys.argv[2]
     #protocol_S = "protocol_D_S.py"
     #protocol_C = "protocol_D_C.py"
     #若设置参数：则为
     #protocol_S = name+"_S.py"
     #protocol_C = name+"_C.py"
     #controll(protocol_A_S,protocol_A_C)
     controll(protocol_S,protocol_C)
     #print "hello##world"