import socket
HOST = "192.168.3.36"
PORT = 6633
SPORT = 6634

data = "1234567"
