# coding=utf-8
import os
import socket
HOST = "192.168.3.36"
PORT = 6633
SHOST = "192.168.247.136"
SPORT = 6635
CHOST = "192.168.247.135"
CPORT = 6635

if __name__ == '__main__':
    path = "C:/Users/wt741/Desktop/hello.py"
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    #s.connect((SHOST, SPORT))
    s.connect((CHOST,CPORT))
    with open(path, 'rb') as f:
        lenth = 0
        while 1:
            data = f.read(1024)
            print data
            if lenth:
                s.send(data)
            else:
                s.send(path.encode() + '####'.encode() + data)
            if len(data) < 1024:
                break
            lenth += len(data)
    s.close()
    #os.remove(path)
