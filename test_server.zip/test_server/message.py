import socket
UHOST = "192.168.3.36"
UPORT = 6634

def mess_send(mess):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((UHOST,UPORT))
    s.send(mess)
    s.close()