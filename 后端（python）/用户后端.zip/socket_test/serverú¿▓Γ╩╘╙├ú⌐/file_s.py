# coding=utf-8
import os
import socket
HOST = "192.168.3.36"
PORT = 6633
SPORT = 6634

if __name__ == '__main__':
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.bind((HOST,PORT))
    s.listen(5)
    print "start listening!"
    while True:
        connect,addr = s.accept()
        info = "".encode()
        while True:
            data = connect.recv(1024)
            info += data
            if not data:
                break
        #print "info："+info
        info = info.split("####".encode())
        #print "info_split:"
        #print info
        file_r_path = info[0].decode()
        #print "file_name:"+file_name
        file_data = info[1]
        #print "file_name_split:"
        #print (file_name.split("/"))
        file_name = file_r_path.split("/")[-1]
       #print "file_name3:"
        #print file_name
        file_path = "D:/data/"+file_name
        #print file_path
        #创建路径
        #os.makedirs(file_path,exist_ok=True)
        #保存
        with open(file_path,"wb") as f:
            f.write(file_data)
            print "success"
        connect.close()
        if data =="-1":
            break
    s.close()
