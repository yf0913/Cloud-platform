# coding=utf-8
import os
import socket
HOST = "192.168.247.136"
PORT = 6634

def controller(name):
    os.system("python /home/server/PycharmProjects/test_server/Warehouse/"+name)

if __name__ == '__main__':
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.bind((HOST,PORT))
    s.listen(5)
    print "start listening!"
    count = 0
    while True:
        connect,addr = s.accept()
        data = connect.recv(1024)
        print "run:"+data
        controller(data)
        connect.close()
        # if data =="-1":
        #     break
        #break
    s.close()

